import { Metadata } from 'next';
import Image from 'next/image';
import Link from 'next/link';
import CTA from '@/components/CTA';
import { getAlbums } from '@/lib/content';
import { generateSEO } from '@/lib/seo';
import { generateBreadcrumbSchema } from '@/lib/structured-data';

export const metadata: Metadata = generateSEO({
  title: 'Portfolio',
  description: 'Bekijk het portfolio van Tigran Media. Professionele fotografie in portretten, evenementen, producten en meer.',
  url: '/portfolio',
});

export default function PortfolioPage() {
  const albums = getAlbums();
  const breadcrumbSchema = generateBreadcrumbSchema([
    { name: 'Home', url: '/' },
    { name: 'Portfolio', url: '/portfolio' },
  ]);

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }}
      />

      {/* Hero + Category Grid — compact */}
      <section className="pt-28 md:pt-32 pb-10 bg-black">
        <div className="max-w-7xl xl:max-w-[1400px] 2xl:max-w-[1600px] 3xl:max-w-[1800px] 4xl:max-w-[85%] 5xl:max-w-[80%] mx-auto px-4 sm:px-6 lg:px-8 2xl:px-12 4xl:px-16">
          <div className="text-center">
            <p className="text-white/50 text-sm tracking-[0.3em] uppercase mb-4 font-body">
              Ons Werk
            </p>
            <h1 className="text-4xl md:text-6xl font-heading font-bold text-white">
              Portfolio
            </h1>
          </div>
        </div>
      </section>

      <section className="pt-10 pb-20 3xl:pb-28 4xl:pb-36 bg-primary">
        <div className="max-w-7xl xl:max-w-[1400px] 2xl:max-w-[1600px] 3xl:max-w-[1800px] 4xl:max-w-[85%] 5xl:max-w-[80%] mx-auto px-4 sm:px-6 lg:px-8 2xl:px-12 4xl:px-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {albums.map((album) => (
              <Link
                key={album.id}
                href={`/portfolio/${album.slug}/`}
                className="group relative block overflow-hidden aspect-[4/3]"
              >
                <Image
                  src={album.coverImage}
                  alt={album.title}
                  fill
                  className="object-cover transition-transform duration-700 group-hover:scale-110"
                  sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent group-hover:from-black/90 transition-all duration-500" />
                <div className="absolute inset-0 flex flex-col justify-end p-6">
                  <h3 className="text-white text-xl md:text-2xl font-heading font-bold group-hover:text-white transition-colors duration-300">
                    {album.title}
                  </h3>
                  <p className="text-white/80 text-sm mt-2 line-clamp-2">
                    {album.description}
                  </p>
                  <span className="inline-flex items-center text-white/50 text-sm mt-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    Bekijk foto&apos;s &rarr;
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <CTA
        title="Wilt u ook zulke foto's?"
        description="Neem contact op voor een vrijblijvende offerte en ontdek wat Tigran Media voor u kan betekenen."
      />
    </>
  );
}
