import { Metadata } from 'next';
import Image from 'next/image';
import Link from 'next/link';
import BlogCard from '@/components/BlogCard';
import { getBlogPosts } from '@/lib/content';
import { generateSEO } from '@/lib/seo';
import { generateBreadcrumbSchema } from '@/lib/structured-data';

export const metadata: Metadata = generateSEO({
  title: 'Blog',
  description: 'Lees de nieuwste artikelen over fotografie, tips voor fotoshoots, de beste fotolocaties in Vlaanderen en meer op de Tigran Media blog.',
  url: '/blog',
});

export default function BlogPage() {
  const posts = getBlogPosts();
  const breadcrumbSchema = generateBreadcrumbSchema([
    { name: 'Home', url: '/' },
    { name: 'Blog', url: '/blog' },
  ]);

  const featuredPost = posts[0];
  const otherPosts = posts.slice(1);

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }}
      />

      {/* Hero */}
      <section className="pt-28 md:pt-32 pb-10 bg-black">
        <div className="max-w-7xl xl:max-w-[1400px] 2xl:max-w-[1600px] 3xl:max-w-[1800px] 4xl:max-w-[85%] 5xl:max-w-[80%] mx-auto px-4 sm:px-6 lg:px-8 2xl:px-12 4xl:px-16">
          <div className="text-center">
            <p className="text-white/50 text-sm tracking-[0.3em] uppercase mb-4 font-body">
              Insights &amp; Tips
            </p>
            <h1 className="text-4xl md:text-6xl font-heading font-bold text-white">
              Blog
            </h1>
          </div>
        </div>
      </section>

      {/* Featured Post */}
      {featuredPost && (
        <section className="py-20 3xl:py-28 4xl:py-36 bg-primary">
          <div className="max-w-7xl xl:max-w-[1400px] 2xl:max-w-[1600px] 3xl:max-w-[1800px] 4xl:max-w-[85%] 5xl:max-w-[80%] mx-auto px-4 sm:px-6 lg:px-8 2xl:px-12 4xl:px-16">
            <Link href={`/blog/${featuredPost.slug}/`} className="group block">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                <div className="aspect-[16/10] relative overflow-hidden">
                  <Image
                    src={featuredPost.coverImage}
                    alt={featuredPost.title}
                    fill
                    className="object-cover transition-transform duration-700 group-hover:scale-105"
                    sizes="(max-width: 1024px) 100vw, 50vw"
                  />
                  <div className="absolute top-4 left-4">
                    <span className="px-3 py-1 bg-white text-black text-xs uppercase tracking-wider">
                      Uitgelicht
                    </span>
                  </div>
                </div>
                <div className="space-y-4">
                  <span className="text-white/50 text-sm tracking-wider uppercase">
                    {featuredPost.category}
                  </span>
                  <h2 className="text-3xl md:text-4xl font-heading font-bold text-white group-hover:text-white transition-colors">
                    {featuredPost.title}
                  </h2>
                  <p className="text-white/60 leading-relaxed">
                    {featuredPost.excerpt}
                  </p>
                  <p className="text-white/50 text-sm">
                    {new Date(featuredPost.date).toLocaleDateString('nl-BE', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric',
                    })}
                  </p>
                  <span className="inline-block text-white/50 text-sm uppercase tracking-wider group-hover:underline">
                    Lees meer →
                  </span>
                </div>
              </div>
            </Link>
          </div>
        </section>
      )}

      {/* Other Posts */}
      {otherPosts.length > 0 && (
        <section className="py-20 3xl:py-28 4xl:py-36 bg-primary-light">
          <div className="max-w-7xl xl:max-w-[1400px] 2xl:max-w-[1600px] 3xl:max-w-[1800px] 4xl:max-w-[85%] 5xl:max-w-[80%] mx-auto px-4 sm:px-6 lg:px-8 2xl:px-12 4xl:px-16">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 4xl:gap-12">
              {otherPosts.map((post, index) => (
                <BlogCard
                  key={post.slug}
                  title={post.title}
                  excerpt={post.excerpt}
                  coverImage={post.coverImage}
                  date={post.date}
                  slug={post.slug}
                  category={post.category}
                  index={index}
                />
              ))}
            </div>
          </div>
        </section>
      )}
    </>
  );
}
