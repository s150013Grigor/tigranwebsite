import { Metadata } from 'next';
import Link from 'next/link';
import Image from 'next/image';
import { cities, getCityBySlug } from '@/data/cities';
import { getAlbums } from '@/lib/content';
import { generateSEO } from '@/lib/seo';
import { generateCityServiceSchema, generateBreadcrumbSchema, generateFAQSchema } from '@/lib/structured-data';
import FAQSection from '@/components/FAQSection';
import ContactForm from '@/components/ContactForm';
import Gallery from '@/components/Gallery';
import Parallax from '@/components/Parallax';

export function generateStaticParams() {
  return cities.map((city) => ({ city: city.slug }));
}

export function generateMetadata({ params }: { params: { city: string } }): Metadata {
  const city = getCityBySlug(params.city);
  if (!city) return {};

  return generateSEO({
    title: `Fotograaf ${city.name} — Professionele Fotografie in ${city.name}`,
    description: `Op zoek naar een professionele fotograaf in ${city.name}? Tigran Media biedt portret-, zakelijke, evenement- en productfotografie in ${city.name}, ${city.province}. Boek nu uw fotoshoot!`,
    url: `/fotograaf/${city.slug}`,
  });
}

export default function CityPage({ params }: { params: { city: string } }) {
  const city = getCityBySlug(params.city);
  if (!city) return <div className="pt-32 text-center text-white">Stad niet gevonden</div>;

  const albums = getAlbums();
  const citySchema = generateCityServiceSchema(city.name, city.slug);
  const breadcrumbSchema = generateBreadcrumbSchema([
    { name: 'Home', url: '/' },
    { name: `Fotograaf ${city.name}`, url: `/fotograaf/${city.slug}` },
  ]);

  const cityFAQs = [
    {
      id: `${city.slug}-1`,
      question: `Wat kost een fotograaf in ${city.name}?`,
      answer: `De tarieven voor professionele fotografie in ${city.name} variëren afhankelijk van het type shoot. Portretfotografie begint vanaf €150, zakelijke fotografie vanaf €250 en evenementfotografie vanaf €500. Neem contact op met Tigran Media voor een persoonlijke offerte.`,
    },
    {
      id: `${city.slug}-2`,
      question: `Waar kan ik mooie foto's laten maken in ${city.name}?`,
      answer: `${city.name} biedt tal van prachtige locaties voor fotoshoots. Wij kennen ${city.description} door en door en helpen u graag bij het kiezen van de perfecte locatie voor uw shoot.`,
    },
    {
      id: `${city.slug}-3`,
      question: `Hoe boek ik een fotoshoot in ${city.name}?`,
      answer: `U kunt eenvoudig een fotoshoot boeken via ons contactformulier, door te bellen naar +32 474 11 48 99 of door te mailen naar info@tigranmedia.be. We plannen graag een vrijblijvend kennismakingsgesprek.`,
    },
    {
      id: `${city.slug}-4`,
      question: `Welke soorten fotografie biedt Tigran Media aan in ${city.name}?`,
      answer: `In ${city.name} bieden wij een breed scala aan fotografiediensten: portretfotografie, zakelijke fotografie, evenementfotografie, productfotografie, familiefotografie en fotoshoots op locatie. Elk type shoot wordt aangepast aan uw specifieke wensen.`,
    },
  ];

  const faqSchema = generateFAQSchema(cityFAQs);

  const galleryItems = albums.slice(0, 6).map((album) => ({
    id: album.id,
    title: album.title,
    slug: album.slug,
    coverImage: album.coverImage,
    category: album.category,
    description: album.description,
    href: `/portfolio/${album.slug}/`,
  }));

  // Get neighboring cities for internal linking
  const neighborCities = cities
    .filter((c) => c.province === city.province && c.slug !== city.slug)
    .slice(0, 8);

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(citySchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
      />

      {/* Hero */}
      <Parallax
        backgroundImage="https://images.unsplash.com/photo-1452587925148-ce544e77e70d?w=1920&h=800&fit=crop"
        speed={0.3}
        overlayOpacity={0.65}
        height="60vh"
      >
        <div className="text-center px-4">
          <p className="text-accent text-sm tracking-[0.3em] uppercase mb-4 font-body">
            Professionele Fotograaf
          </p>
          <h1 className="text-4xl md:text-6xl font-heading font-bold text-white mb-4">
            Fotograaf in {city.name}
          </h1>
          <p className="text-gray-300 text-lg max-w-2xl mx-auto">
            Op zoek naar een professionele fotograaf in {city.name}? Tigran Media legt uw
            mooiste momenten vast in {city.description}.
          </p>
        </div>
      </Parallax>

      {/* Content Section */}
      <section className="py-20 bg-primary">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex items-center space-x-2 text-sm text-gray-400 mb-8">
            <Link href="/" className="hover:text-accent transition-colors">Home</Link>
            <span>/</span>
            <span className="text-white">Fotograaf {city.name}</span>
          </nav>

          <div className="prose-custom">
            <h2>Professionele Fotografie in {city.name}</h2>
            <p>
              Bent u op zoek naar een ervaren en professionele fotograaf in {city.name}? 
              Tigran Media is uw betrouwbare partner voor alle soorten fotografie in {city.name} 
              en de rest van {city.province}. Met jarenlange ervaring en een passie voor 
              het vastleggen van bijzondere momenten, leveren wij fotografie van de hoogste kwaliteit.
            </p>
            <p>
              {city.name} is {city.description}. Deze prachtige omgeving biedt eindeloze 
              mogelijkheden voor sfeervolle fotoshoots. Of u nu op zoek bent naar een fotograaf 
              voor een professioneel portret, een bedrijfsevenement of 
              productfotografie — Tigran Media staat voor u klaar.
            </p>

            <h2>Onze Diensten in {city.name}</h2>
            <p>
              Als fotograaf in {city.name} bieden wij een uitgebreid pakket aan 
              fotografiediensten:
            </p>
            <ul>
              <li><strong>Zakelijke Fotografie in {city.name}</strong> — Professionele foto’s voor uw bedrijf</li>
              <li><strong>Portretfotografie in {city.name}</strong> — Professionele portretten voor elk doel</li>
              <li><strong>Evenementfotografie in {city.name}</strong> — Bedrijfsevents en feesten</li>
              <li><strong>Productfotografie in {city.name}</strong> — Uw producten in het beste licht</li>
              <li><strong>Familiefotografie in {city.name}</strong> — Warme familiemomenten</li>
            </ul>

            <h2>Waarom Tigran Media in {city.name}?</h2>
            <p>
              Als lokale fotograaf actief in {city.name} en omgeving kennen wij de mooiste 
              locaties en het beste licht. Wij combineren technische expertise met een 
              artistiek oog om foto&apos;s te maken die niet alleen mooi zijn, maar ook een verhaal 
              vertellen. Onze persoonlijke aanpak zorgt ervoor dat u zich op uw gemak voelt, 
              wat resulteert in natuurlijke en authentieke beelden.
            </p>
          </div>
        </div>
      </section>

      {/* Portfolio Preview */}
      <Gallery
        items={galleryItems}
        columns={3}
        title={`Portfolio — ${city.name}`}
        subtitle="Ons werk"
      />

      {/* FAQ */}
      <FAQSection
        faqs={cityFAQs}
        title={`FAQ — Fotograaf ${city.name}`}
        subtitle="Veelgestelde vragen"
      />

      {/* Contact */}
      <ContactForm
        title={`Boek Uw Fotoshoot in ${city.name}`}
        subtitle={`Fotograaf ${city.name}`}
        showInfo={true}
      />

      {/* Nearby Cities */}
      {neighborCities.length > 0 && (
        <section className="py-16 bg-primary-dark">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-2xl font-heading font-bold text-white mb-8 text-center">
              Ook Actief in de Buurt van {city.name}
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {neighborCities.map((nc) => (
                <Link
                  key={nc.slug}
                  href={`/fotograaf/${nc.slug}/`}
                  className="p-4 bg-primary-light border border-white/5 hover:border-accent/30 transition-all text-center group"
                >
                  <p className="text-white group-hover:text-accent transition-colors font-heading">
                    Fotograaf {nc.name}
                  </p>
                  <p className="text-gray-500 text-xs mt-1">{nc.province}</p>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}
    </>
  );
}
