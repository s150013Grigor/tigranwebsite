import { Metadata } from 'next';
import AboutSection from '@/components/AboutSection';
import { generateSEO } from '@/lib/seo';

export const metadata: Metadata = generateSEO({
  title: 'Over Ons - Tigran Media',
  description: 'Leer meer over Tigran Media — professionele fotograaf in Vlaanderen. Uw verhaal, mijn passie.',
  url: '/over-ons',
});

export default function OverOnsPage() {
  return (
    <div className="pt-20">
      <AboutSection />
    </div>
  );
}
