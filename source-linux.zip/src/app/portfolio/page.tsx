import { Metadata } from 'next';
import Gallery from '@/components/Gallery';
import CTA from '@/components/CTA';
import Parallax from '@/components/Parallax';
import { getAlbums } from '@/lib/content';
import { generateSEO } from '@/lib/seo';
import { generateBreadcrumbSchema } from '@/lib/structured-data';

export const metadata: Metadata = generateSEO({
  title: 'Portfolio',
  description: 'Bekijk het portfolio van Tigran Media. Professionele fotografie in portretten, evenementen, producten, families en natuur.',
  url: '/portfolio',
});

export default function PortfolioPage() {
  const albums = getAlbums();
  const breadcrumbSchema = generateBreadcrumbSchema([
    { name: 'Home', url: '/' },
    { name: 'Portfolio', url: '/portfolio' },
  ]);

  const galleryItems = albums.map((album) => ({
    id: album.id,
    title: album.title,
    slug: album.slug,
    coverImage: album.coverImage,
    category: album.category,
    description: album.description,
    href: `/portfolio/${album.slug}/`,
  }));

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }}
      />

      {/* Hero */}
      <Parallax
        backgroundImage="https://images.unsplash.com/photo-1452587925148-ce544e77e70d?w=1920&h=800&fit=crop"
        speed={0.3}
        overlayOpacity={0.65}
        height="60vh"
      >
        <div className="text-center px-4">
          <p className="text-accent text-sm tracking-[0.3em] uppercase mb-4 font-body">
            Ons Werk
          </p>
          <h1 className="text-4xl md:text-6xl font-heading font-bold text-white mb-4">
            Portfolio
          </h1>
          <p className="text-gray-300 text-lg max-w-2xl mx-auto">
            Ontdek onze collectie van professionele fotografie. Van portretten tot producten — elk project is uniek.
          </p>
        </div>
      </Parallax>

      {/* Gallery */}
      <Gallery
        items={galleryItems}
        columns={3}
        title="Albums"
        subtitle="Verken onze categoriëen"
      />

      {/* CTA */}
      <CTA
        title="Wilt u ook zulke foto's?"
        description="Neem contact op voor een vrijblijvende offerte en ontdek wat Tigran Media voor u kan betekenen."
      />
    </>
  );
}
