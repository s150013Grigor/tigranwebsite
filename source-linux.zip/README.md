# Tigran Media — Professionele Fotografie Website

Een volledig statisch gegenereerde fotografiewebsite gebouwd met **Next.js 14**, **TypeScript** en **Tailwind CSS**. Gehost op AWS (S3 + CloudFront) met serverless contactformulier via Lambda + SES.

## 🏗️ Architectuur

```
┌─────────────┐     ┌──────────────┐     ┌─────────────┐
│  Next.js    │────▶│  S3 Bucket   │────▶│ CloudFront  │──▶ gebruiker
│  Static     │     │  (hosting)   │     │  (CDN)      │
│  Export     │     └──────────────┘     └──────┬──────┘
└─────────────┘                                 │
                                                │ /api/contact
                                         ┌──────▼──────┐
                                         │ API Gateway  │
                                         └──────┬──────┘
                                                │
                                         ┌──────▼──────┐     ┌─────────┐
                                         │   Lambda    │────▶│   SES   │──▶ email
                                         └─────────────┘     └─────────┘
```

## 📁 Projectstructuur

```
├── src/
│   ├── app/                    # Next.js App Router pagina's
│   │   ├── page.tsx            # Homepage
│   │   ├── layout.tsx          # Root layout + structured data
│   │   ├── globals.css         # Globale stijlen
│   │   ├── portfolio/          # Portfolio overzicht + [album] + [photo]
│   │   ├── blog/               # Blog overzicht + [slug]
│   │   ├── contact/            # Contactpagina
│   │   ├── faq/                # FAQ pagina
│   │   ├── fotograaf/[city]/   # ~75 stad-specifieke landingspagina's
│   │   ├── varianten/          # 10 varianten per component (100 totaal)
│   │   ├── admin/              # CMS admin panel (dev only)
│   │   ├── terms-of-service/   # Algemene voorwaarden
│   │   └── privacy-policy/     # Privacybeleid (GDPR)
│   ├── components/             # Herbruikbare React componenten
│   ├── content/                # Content bestanden (JSON + Markdown)
│   │   ├── albums.json         # Album data
│   │   ├── photos.json         # Foto data
│   │   ├── faq.json            # FAQ items
│   │   └── blog/               # Markdown blog posts
│   ├── data/
│   │   └── cities.ts           # ~75 Vlaamse steden
│   └── lib/
│       ├── content.ts          # Data access layer
│       ├── seo.ts              # SEO metadata generator
│       └── structured-data.ts  # Schema.org structured data
├── cms/
│   └── server.js               # Express CMS API (dev only)
├── lambda/
│   └── contact-form/           # AWS Lambda contactformulier
├── terraform/                  # Infrastructure as Code
│   ├── main.tf                 # Provider configuratie
│   ├── variables.tf            # Variabelen
│   ├── s3.tf                   # S3 bucket configuratie
│   ├── cloudfront.tf           # CloudFront distributie
│   ├── lambda.tf               # Lambda + API Gateway + SES
│   └── outputs.tf              # Output waarden
├── scripts/
│   └── generate-sitemap.js     # Sitemap generator
├── public/
│   └── robots.txt              # Robots.txt
└── fotos/                      # Eigen foto's (voeg hier je foto's toe)
```

## 🚀 Aan de Slag

### Vereisten

- Node.js 18+
- npm of yarn
- AWS CLI (voor deployment)
- Terraform (voor infrastructuur)

### Installatie

```bash
# Dependencies installeren
npm install

# Development server starten
npm run dev

# Met CMS admin (development)
npm run cms
```

### Build & Export

```bash
# Sitemap genereren
npm run generate-sitemap

# Statische site bouwen
npm run build

# Build output staat in /out
```

### Deployment naar AWS

```bash
# 1. Terraform initialiseren
cd terraform
terraform init

# 2. Plan bekijken
terraform plan

# 3. Infrastructuur deployen
terraform apply

# 4. Website deployen
cd ..
npm run deploy
```

## ⚙️ Configuratie

### Google Analytics & Ads

Open `src/app/layout.tsx` en vervang de placeholders:

```tsx
// Google Analytics - vervang G-XXXXXXXXXX met je Measurement ID
// Ga naar: https://analytics.google.com → Admin → Data Streams → Measurement ID

// Google Ads - vervang AW-XXXXXXXXX met je Conversion ID
// Ga naar: https://ads.google.com → Tools → Conversions
```

### Contactformulier

Stel de API endpoint in als environment variable:

```env
NEXT_PUBLIC_CONTACT_API_ENDPOINT=https://jouw-api-id.execute-api.eu-west-1.amazonaws.com/api/contact
```

Na Terraform deployment krijg je deze URL als output.

### Eigen Foto's

1. Plaats je foto's in de `fotos/` map of upload naar een CDN
2. Update `src/content/photos.json` met de juiste paden
3. Update `src/content/albums.json` met cover images
4. Herbouw de site: `npm run build`

### Steden aanpassen

Bewerk `src/data/cities.ts` om steden toe te voegen of te verwijderen for de fotograaf-in-[stad] pagina's.

## 📄 Pagina's

| Pagina | Route | Beschrijving |
|--------|-------|-------------|
| Home | `/` | Hero, diensten, galerij, over ons, testimonials, blog preview |
| Portfolio | `/portfolio` | Overzicht van alle albums |
| Album | `/portfolio/[album]` | Foto's per album |
| Foto | `/portfolio/[album]/[photo]` | Individuele foto met details |
| Blog | `/blog` | Blog overzicht |
| Blogpost | `/blog/[slug]` | Individueel artikel |
| Contact | `/contact` | Contactformulier |
| FAQ | `/faq` | Veelgestelde vragen |
| Fotograaf | `/fotograaf/[stad]` | ~75 stad-specifieke SEO pagina's |
| Varianten | `/varianten` | Component varianten overzicht |
| Variant | `/varianten/[component]` | 10 varianten per component |
| Voorwaarden | `/terms-of-service` | Algemene voorwaarden |
| Privacy | `/privacy-policy` | GDPR privacybeleid |
| Admin | `/admin` | CMS admin panel (dev only) |

## 🎨 Component Varianten

Bezoek `/varianten` om alle 100 componentvariaties te bekijken:

- **Hero** — 10 hero secties (classic, split, parallax, cinematic, etc.)
- **Gallery** — 10 galerij layouts (grid, masonry, carousel, polaroid, etc.)
- **Testimonials** — 10 review presentaties (cards, quotes, timeline, etc.)
- **CTA** — 10 call-to-action stijlen (solid, parallax, newsletter, etc.)
- **About** — 10 over-ons secties (two-column, timeline, skills, etc.)
- **Contact** — 10 contactformulier designs (classic, chat, map, etc.)
- **FAQ** — 10 FAQ layouts (accordion, tabs, bubbles, etc.)
- **Blog Cards** — 10 blog kaart stijlen (cards, overlay, magazine, etc.)
- **Footer** — 10 footer designs (4-column, minimal, CTA, etc.)
- **Header** — 10 navigatie stijlen (classic, transparent, pill, sidebar, etc.)

## 🔧 CMS Admin

Het CMS is alleen beschikbaar in development mode:

```bash
npm run cms
```

Dit start:
- Next.js dev server op `http://localhost:3000`
- CMS API server op `http://localhost:3001`

Ga naar `http://localhost:3000/admin` om albums, foto's, blog posts en FAQ items te beheren.

## 📊 SEO Features

- **Meta tags** per pagina (title, description, Open Graph, Twitter Cards)
- **Structured Data** (Schema.org): LocalBusiness, Photographer, Article, FAQ, ImageObject, BreadcrumbList
- **Sitemap.xml** automatisch gegenereerd met alle ~150+ pagina's
- **Robots.txt** met sitemap referentie
- **~75 stadpagina's** voor lokale SEO (fotograaf in [stad])
- **Semantische HTML** met juiste heading hiërarchie
- **Alt teksten** op alle afbeeldingen
- **Internal linking** via footer, stad-naar-stad links, gerelateerde posts

## 🛠️ Technologie Stack

- **Framework**: Next.js 14 (App Router, Static Export)
- **Taal**: TypeScript
- **Styling**: Tailwind CSS
- **Animaties**: Framer Motion
- **Blog**: Markdown met gray-matter + react-markdown
- **Iconen**: react-icons
- **Hosting**: AWS S3 + CloudFront
- **Contact**: AWS Lambda + SES
- **IaC**: Terraform
- **CMS**: Express.js (development)

## 📝 Licentie

Alle rechten voorbehouden © 2024 Tigran Media
